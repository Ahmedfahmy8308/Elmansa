import 'package:elmanasa/helper/dataLevel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:elmanasa/model/levelModel.dart';
import 'package:elmanasa/model/CourseModel.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

class HomePage extends StatefulWidget {
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<LevelModel> levels = [];
  List<CourseModel> courses = [];
  bool _loading = true;
  void initState() {
    levels = getLevel();
  }

  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xffFFFFFFF),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Color(0xffFFFFFFF),
          flexibleSpace: SafeArea(
            child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Hello',
                          style: GoogleFonts.notoSans(
                              fontSize: 16,
                              color: Color(0xff747474),
                              fontWeight: FontWeight.bold),
                        )
                      ],
                    )
                  ],
                )),
          ),
        ),
        body: _loading
            ? Center(
                child: Container(
                child: SpinKitWave(
                  color: Colors.blue,
                  size: 50.0,
                ),
              ))
            : SingleChildScrollView(child: Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  ),
                  child: Column(
                  children: [Container(
                    padding: EdgeInsets.symmetric(vertical: 12),
                  alignment: Alignment.topLeft,
                  child: Text('Levels',style: GoogleFonts.notoSans(fontSize: 20,fontWeight: FontWeight.bold,color: Color(0xff232323)),),
                  ),Container(
                    padding: EdgeInsets.only(top: 40,),width: double.infinity,
                    height: 200, child:,
                  )],),
                  )));
  }
}
