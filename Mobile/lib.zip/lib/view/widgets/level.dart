import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Level extends StatelessWidget {
   String ?logo;
   int ? level;
   Color ?color;
  Level({this.logo, this.level, this.color});
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      height: 157,
      width: 128,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(16)),
        margin: EdgeInsets.only(right:14,),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("${logo}",style: GoogleFonts.poppins(color:Colors.white,fontSize: 20),),
            
            Padding(
              padding: const EdgeInsets.only(top:14),
              child: Text("Level ${level}",style: GoogleFonts.poppins(color:Colors.white,fontSize: 16),),
            ),
          ],
        ),
      
    );
  }
}
