import 'package:flutter/material.dart';
import 'package:elmanasa/model/levelModel.dart';

List<LevelModel> getLevel() {
  List<LevelModel> levels = <LevelModel>[];

  
  LevelModel levelmodel11 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 1,
    levelexp:'One Two Three',
    stage: 'Primary' 
  );
  levels.add(levelmodel11);
   LevelModel levelmodel12 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 2,
    levelexp:'1+2=3',
    stage: 'Primary' 
  );
  levels.add(levelmodel12);
     LevelModel levelmodel13 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 3,
    levelexp:'6 × 2 = 12',
    stage: 'Primary' 
  );
  levels.add(levelmodel13); 
    LevelModel levelmodel14 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 4,
    levelexp:'15 ÷ 3 = 5',
    stage: 'Primary' 
  );
  levels.add(levelmodel14);  
   LevelModel levelmodel15 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 5,
    levelexp:'4² = 16',
    stage: 'Primary' 
  );
  levels.add(levelmodel15);  
   LevelModel levelmodel16 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 6,
    levelexp:'2x + 5 = 15',
    stage: 'Primary' 
  );
  levels.add(levelmodel16);

     LevelModel levelmodel21 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 1,
    levelexp:'Area = length × width',
    stage: 'Preparatory' 
  );
  levels.add(levelmodel21);
     LevelModel levelmodel22 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 2,
    levelexp:'√64 = 8',
    stage: 'Preparatory' 
  );
  levels.add(levelmodel22);
     LevelModel levelmodel23 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 3,
    levelexp:'x² - 5x + 6 = 0',
    stage: 'Preparatory' 
  );
  levels.add(levelmodel23);

     LevelModel levelmodel31 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 1,
    levelexp:'log₁₀ 100 = 2',
    stage: 'Secondary' 
  );
  levels.add(levelmodel31);
     LevelModel levelmodel32 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 2,
    levelexp:'sin²(x)+cos²(x)=1',
    stage: 'Secondary' 
  );
  levels.add(levelmodel32);
     LevelModel levelmodel33 = LevelModel(
    color: Color.fromRGBO(153, 202, 225, 1),
    level: 3,
    levelexp:'dx/d(x²)=2x',
    stage: 'Secondary' 
  );
  levels.add(levelmodel33);


  return levels;
}
